using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CustomSpawner : MonoBehaviour
{
    public GameObject[] customerPrefabs;
    public GameObject[] badCustomerPrefabs;
    public Transform[] spawnPoints;
    public float badCustomerChance = 0.1f;

    private int clearedCustomerCount = 0;
    private List<Transform> availableSpawnPoints = new List<Transform>();
    private HashSet<Transform> occupiedSpawnPoints = new HashSet<Transform>(); // ✅ 중복 방지용

    private void Start()
    {
        availableSpawnPoints.AddRange(spawnPoints);
        StartCoroutine(SpawnLoop());
    }

    IEnumerator SpawnLoop()
    {
        while (true)
        {
            int activeCustomers = GameObject.FindGameObjectsWithTag("Custom").Length;
            int maxCustomers = Mathf.Clamp(clearedCustomerCount < 3 ? 6 : 12, 1, 12);

            if (activeCustomers < maxCustomers)
            {
                SpawnRandomCustomer();
            }

            yield return new WaitForSeconds(10f);
        }
    }

    public void SpawnRandomCustomer()
    {
        // 🔒 선택 가능한 위치가 없으면 리턴
        List<Transform> validSpawnPoints = new List<Transform>();

        foreach (Transform point in spawnPoints)
        {
            if (!occupiedSpawnPoints.Contains(point))
                validSpawnPoints.Add(point);
        }

        if (validSpawnPoints.Count == 0)
        {
            Debug.LogWarning("모든 스폰 포인트가 사용 중입니다.");
            return;
        }

        // ✅ 랜덤 선택
        Transform selectedSpawnPoint = validSpawnPoints[Random.Range(0, validSpawnPoints.Count)];

        bool spawnBad = !GameManager.instance.hasBadCustomer && Random.value < badCustomerChance;

        GameObject prefabToSpawn = spawnBad ?
            badCustomerPrefabs[Random.Range(0, badCustomerPrefabs.Length)] :
            customerPrefabs[Random.Range(0, customerPrefabs.Length)];

        GameObject newCustomer = Instantiate(prefabToSpawn, selectedSpawnPoint.position, Quaternion.identity);
        Custom custom = newCustomer.GetComponent<Custom>();

        if (custom != null)
        {
            custom.spawner = this;
            custom.isBadCustomer = spawnBad;
            custom.spawnPoint = selectedSpawnPoint;

            if (spawnBad)
            {
                GameManager.instance.hasBadCustomer = true;
                GameManager.instance.badCustomer = custom;
            }

            // 🧩 중복 방지 등록
            occupiedSpawnPoints.Add(selectedSpawnPoint);
        }
    }

    public void RespawnCustomer(GameObject oldCustomer)
    {
        Custom custom = oldCustomer.GetComponent<Custom>();
        if (custom != null && custom.spawnPoint != null)
        {
            // ✅ 자리를 다시 사용 가능하게
            occupiedSpawnPoints.Remove(custom.spawnPoint);
        }

        StartCoroutine(RespawnRoutine(oldCustomer));
    }

    IEnumerator RespawnRoutine(GameObject oldCustomer)
    {
        Destroy(oldCustomer);
        yield return new WaitForSeconds(3f);
        SpawnRandomCustomer();
    }

    public void OnCustomerCleared()
    {
        clearedCustomerCount++;
        GameManager.instance.IncreaseCustomerCount();
    }
}
