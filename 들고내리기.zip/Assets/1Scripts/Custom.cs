﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Custom : MonoBehaviour
{
    public enum BadType { None, Dalgona, Hotdog, Stun }
    public BadType badType = BadType.None;

    // ====== 상태 ======
    private bool isPlayerInZone = false;
    private bool isRequesting = false;
    private bool isBeingDelivered = false;
    private float waitTimer = 0f;
    private float maxWaitTime = 40f; // 손님 대기 시간 (초)
    
    private Player player;
    private string requestedFood = "";

    public bool IsBeingDelivered => isBeingDelivered;
    public string RequestedFood => requestedFood;

    // ====== 외부 연결 ======
    public CustomSpawner spawner;
    public bool isBadCustomer = false;
    public Transform spawnPoint;

    private Coroutine stunCoroutine;



    // ======= UI 요소=======
    public Image orderIconImage; // 손님 머리 위 아이콘 이미지
    public Sprite dalgonaSprite;
    public Sprite hottukSprite;
    public Sprite hotdogSprite;
    public Sprite boungSprite;

    private void Start()
    {
        if (!isRequesting && !isBadCustomer)
            RequestRandomFood();

        if (isBadCustomer)
        {
            GameManager.instance.hasBadCustomer = true;
            GameManager.instance.badCustomer = this;

            if (badType == BadType.Stun)
                stunCoroutine = StartCoroutine(StunPlayerRoutine());
        }
    }

    private void Update()
    {
        waitTimer += Time.deltaTime;
        if (waitTimer > maxWaitTime)
        {
            Debug.Log("시간 초과로 손님 제거");
            StartCoroutine(DestroyAndRespawn(false));
        }

        if (isPlayerInZone && Input.GetKeyDown(KeyCode.E)) TryDeliver();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInZone = true;
            player = other.GetComponent<Player>();

            if (!isRequesting && !isBadCustomer)
                RequestRandomFood();
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInZone = false;
            isRequesting = false;
        }
    }

private void RequestRandomFood()
{
    isRequesting = true;
    string[] foods = { "dalgona", "hottuk", "hotdog", "boung" };
    requestedFood = foods[Random.Range(0, foods.Length)];
    Debug.Log($"손님이 요청한 음식: {requestedFood}");

    if (orderIconImage != null)
    {
        switch (requestedFood)
        {
            case "dalgona":
                orderIconImage.sprite = dalgonaSprite;
                break;
            case "hottuk":
                orderIconImage.sprite = hottukSprite;
                break;
            case "hotdog":
                orderIconImage.sprite = hotdogSprite;
                break;
            case "boung":
                orderIconImage.sprite = boungSprite;
                break;
        }

        orderIconImage.enabled = true;
    }
}

    private void TryDeliver()
    {
        if (isBadCustomer)
        {
            switch (badType)
            {
                case BadType.Dalgona:
                    if (player.sugarCount >= 10)
                    {
                        player.sugarCount -= 10;
                        player.Point += 10;
                        Debug.Log("설탕 10개를 줘서 나쁜 손님 제거!");
                        RemoveBadCustomer();
                    }
                    else
                    {
                        Debug.Log("설탕이 부족합니다!");
                    }
                    return;
                case BadType.Hotdog:
                    if (player.sosageCount >= 10)
                    {
                        player.sosageCount -= 10;
                        player.Point += 10;
                        Debug.Log("소세지 10개를 줘서 나쁜 손님 제거!");
                        RemoveBadCustomer();
                    }
                    else
                    {
                        Debug.Log("소세지가 부족합니다!");
                    }
                    return;
                case BadType.Stun:
                    if (player.boungCount >= 2)
                    {
                        player.boungCount -= 2;
                        player.Point += 10;
                        if (stunCoroutine != null) StopCoroutine(stunCoroutine);
                        Debug.Log("붕어빵 2개를 줘서 나쁜 손님 제거!");
                        RemoveBadCustomer();
                    }
                    else
                    {
                        Debug.Log("붕어빵이 부족합니다!");
                    }
                    return;
            }
        }

        bool delivered = false;

        switch (requestedFood)
        {
            case "dalgona":
                delivered = TryGive(ref player.dalgonaCount, "달고나");
                break;
            case "hottuk":
                delivered = TryGive(ref player.hottukCount, "호떡");
                break;
            case "hotdog":
                delivered = TryGive(ref player.hotdogCount, "핫도그");
                break;
            case "boung":
                delivered = TryGive(ref player.boungCount, "붕어빵");
                break;
        }

        if (delivered)
            StartCoroutine(DestroyAndRespawn(true));
    }

    private bool TryGive(ref int itemCount, string itemName)
    {
        if (itemCount > 0)
        {
            itemCount--;
            player.Point += player.basePoint + player.bonusPoint;
            player.customerSuccessCount++;
            Debug.Log($"{itemName} 전달 성공!");
            return true;
        }
        else
        {
            Debug.Log($"{itemName} 부족!");
            return false;
        }
    }

    public void ReceiveAutoDeliveredFood(string foodName)
    {
        isBeingDelivered = false;
        if (requestedFood == foodName)
        {
            Debug.Log("자동 배달 성공!");
            StartCoroutine(DestroyAndRespawn(true));
        }
        else
        {
            Debug.Log("요청과 불일치!");
        }
    }

    public void MarkBeingDelivered() => isBeingDelivered = true;

    private IEnumerator DestroyAndRespawn(bool success)
    {
        isRequesting = false;
        yield return null;

        if (spawner != null)
        {
            if (success)
                spawner.OnCustomerCleared();

            spawner.RespawnCustomer(this.gameObject);
        }

        if (orderIconImage != null)
        {
            orderIconImage.enabled = false;
        }
    }

    public void RemoveBadCustomer()
    {
        if (isBadCustomer)
        {
            GameManager.instance.hasBadCustomer = false;
            GameManager.instance.badCustomer = null;
            StartCoroutine(DestroyAndRespawn(false));
        }
    }

    private IEnumerator StunPlayerRoutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(10f);
            if (player != null)
                player.Stun(0.5f);
        }
    }
}
