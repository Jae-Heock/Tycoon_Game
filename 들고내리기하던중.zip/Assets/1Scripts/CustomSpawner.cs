using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CustomSpawner : MonoBehaviour
{
    public GameObject[] customerPrefabs;
    public GameObject[] badCustomerPrefabs;
    public Transform[] spawnPoints;
    public float badCustomerChance = 0.1f;

    private int clearedCustomerCount = 0;
    private List<Transform> availableSpawnPoints = new List<Transform>();

    private void Start()
    {
        // Initialize available spawn points
        availableSpawnPoints.AddRange(spawnPoints);
        // SpawnInitialCustomers();
        StartCoroutine(SpawnLoop());
    }

    private void SpawnInitialCustomers()
    {
        int initialCount = Mathf.Clamp(clearedCustomerCount < 3 ? 6 : 12, 1, 12);
        for (int i = 0; i < initialCount; i++)
        {
            SpawnRandomCustomer();
        }
    }

    IEnumerator SpawnLoop()
    {
        while (true)
        {
            int activeCustomers = GameObject.FindGameObjectsWithTag("Custom").Length;
            int maxCustomers = Mathf.Clamp(clearedCustomerCount < 3 ? 6 : 12, 1, 12);

            if (activeCustomers < maxCustomers)
            {
                SpawnRandomCustomer();
            }

            yield return new WaitForSeconds(10f);
        }
    }

    public void SpawnRandomCustomer()
    {
        if (availableSpawnPoints.Count == 0)
        {
            Debug.LogWarning("No available spawn points!");
            return;
        }

        int spawnIndex = Random.Range(0, availableSpawnPoints.Count);
        Transform selectedSpawnPoint = availableSpawnPoints[spawnIndex];
        availableSpawnPoints.RemoveAt(spawnIndex);

        bool spawnBad = !GameManager.instance.hasBadCustomer && Random.value < badCustomerChance;

        GameObject prefabToSpawn = spawnBad ?
            badCustomerPrefabs[Random.Range(0, badCustomerPrefabs.Length)] :
            customerPrefabs[Random.Range(0, customerPrefabs.Length)];

        GameObject newCustomer = Instantiate(prefabToSpawn, selectedSpawnPoint.position, Quaternion.identity);
        Custom custom = newCustomer.GetComponent<Custom>();

        if (custom != null)
        {
            custom.spawner = this;
            custom.isBadCustomer = spawnBad;
            custom.spawnPoint = selectedSpawnPoint; // Store reference to spawn point

            if (spawnBad)
            {
                GameManager.instance.hasBadCustomer = true;
                GameManager.instance.badCustomer = custom;
            }
        }
    }

    public void RespawnCustomer(GameObject oldCustomer)
    {
        Custom custom = oldCustomer.GetComponent<Custom>();
        if (custom != null && custom.spawnPoint != null)
        {
            availableSpawnPoints.Add(custom.spawnPoint);
        }
        StartCoroutine(RespawnRoutine(oldCustomer));
    }

    IEnumerator RespawnRoutine(GameObject oldCustomer)
    {
        Destroy(oldCustomer);
        yield return new WaitForSeconds(3f);
        SpawnRandomCustomer();
    }

    public void OnCustomerCleared()
    {
        clearedCustomerCount++;
        GameManager.instance.IncreaseCustomerCount();
    }
}
